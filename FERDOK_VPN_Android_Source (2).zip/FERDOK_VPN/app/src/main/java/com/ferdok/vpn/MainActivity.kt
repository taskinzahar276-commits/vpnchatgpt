package com.ferdok.vpn

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config

class MainActivity : ComponentActivity() {
    private lateinit var backend: Backend
    private val tunnel = AppTunnel()
    private var config: Config? = null
    private var connected by mutableStateOf(false)
    private var message by mutableStateOf("Импортируйте WireGuard-конфиг (.conf)")
    private var waitingForPermission = false

    private val configPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    config = Config.parse(input)
                } ?: error("Не удалось открыть файл")
                message = "Конфигурация загружена. Можно подключаться."
            } catch (e: Exception) {
                config = null
                message = "Ошибка конфига: ${e.message ?: "неверный файл"}"
            }
        }
    }

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (waitingForPermission) {
            waitingForPermission = false
            if (it.resultCode == RESULT_OK) connectNow()
            else message = "Разрешение VPN не выдано"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backend = GoBackend(this)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("FERDOK VPN", style = MaterialTheme.typography.headlineLarge)
                        Spacer(Modifier.height(12.dp))
                        Text(if (connected) "ПОДКЛЮЧЕНО" else "НЕ ПОДКЛЮЧЕНО",
                            style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(12.dp))
                        Text(message)
                        Spacer(Modifier.height(28.dp))
                        Button(onClick = { configPicker.launch(arrayOf("*/*")) }) {
                            Text("Импортировать .conf")
                        }
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = { if (connected) disconnect() else requestConnect() },
                            enabled = connected || config != null
                        ) {
                            Text(if (connected) "Отключить" else "Подключить")
                        }
                    }
                }
            }
        }
    }

    private fun requestConnect() {
        val permissionIntent: Intent? = VpnService.prepare(this)
        if (permissionIntent != null) {
            waitingForPermission = true
            vpnPermission.launch(permissionIntent)
        } else connectNow()
    }

    private fun connectNow() {
        val selected = config ?: run {
            message = "Сначала импортируйте .conf"
            return
        }
        try {
            backend.setState(tunnel, Tunnel.State.UP, selected)
            connected = true
            message = "VPN-туннель запущен"
        } catch (e: Exception) {
            connected = false
            message = "Не удалось подключиться: ${e.message ?: "ошибка"}"
        }
    }

    private fun disconnect() {
        try {
            backend.setState(tunnel, Tunnel.State.DOWN, null)
            connected = false
            message = "VPN отключён"
        } catch (e: Exception) {
            message = "Ошибка отключения: ${e.message ?: "ошибка"}"
        }
    }

    override fun onDestroy() {
        if (::backend.isInitialized && connected) {
            try { backend.setState(tunnel, Tunnel.State.DOWN, null) } catch (_: Exception) {}
        }
        super.onDestroy()
    }

    private class AppTunnel : Tunnel {
        override fun getName(): String = "FERDOK"
        override fun onStateChange(newState: Tunnel.State) {}
    }
}
