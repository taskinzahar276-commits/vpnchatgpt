# FERDOK VPN

Android WireGuard client starter project.

## Build APK
Push the project to GitHub, open **Actions → Build FERDOK VPN APK → Run workflow**.
When the workflow completes, download the `FERDOK-VPN-debug-APK` artifact.

## Connect
Open the app, import a valid WireGuard `.conf` file, approve Android's VPN permission, then tap Connect.

**Important:** this app does not include VPN servers. You need a working WireGuard server and its configuration file. The app stores the imported configuration in memory only; re-import it after restarting the app.

This source has not been built or device-tested in this environment. The first GitHub Actions run is required to verify dependency resolution and compilation.
